/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ParcialFestival;

/**
 *
 * @author tob
 */
public class Taller extends ActividadReservable{
    private int minutosPractica;
    
    public Taller(String codigo, String titulo, FranjaHoraria franja, int duracionBase, int minutosPractica, int cupos){
        super(codigo, titulo, franja, duracionBase, cupos);
        validarNoNegativo(minutosPractica, "minutosPractica");
        this.minutosPractica = minutosPractica;}
    
    public int getMinutosPractica(){
        return minutosPractica;}
    
    @Override
    public String toString(){
        return "Taller [" + super.toString() + ", minutosPractica=" + minutosPractica + ", cupos=" + getCupos() + "]";}
    
}
