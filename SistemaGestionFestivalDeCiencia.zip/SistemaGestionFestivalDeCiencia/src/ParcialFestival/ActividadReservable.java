/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ParcialFestival;

/**
 *
 * @author tob
 */
public abstract class ActividadReservable extends Actividad implements Reservable {
    private int cupos;
    
    public ActividadReservable(String codigo, String titulo, FranjaHoraria franja, int duracionBase, int cupos){
        super(codigo, titulo, franja, duracionBase);
        validarNoNegativo(cupos, "cupos");
        this.cupos = cupos;}
    
    public int getCupos(){
        return cupos;}
    
    @Override
    public String reservarLugar(){
        if (cupos == 0){
            throw new IllegalArgumentException("No quedan lugares disponibles para " + getTitulo());
        }
        cupos--;
        return "Reserva confirmada para " + getTitulo() + ". Cupos restantes: " + cupos + ".";
    }

    private void validarNoNegativo(int cupos, String cupos0) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

