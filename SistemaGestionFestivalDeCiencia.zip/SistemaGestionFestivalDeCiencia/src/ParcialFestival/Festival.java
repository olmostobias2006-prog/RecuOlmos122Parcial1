/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ParcialFestival;
import java.util.Arraylist;
import java.util.List;
/**
 *
 * @author tob
 */
public class Festival {
    private String nombre;
    private List<Actividad> actividades;
    
    public Festival(String nombre){
        if (nombre == null || nombre.trim().equals("")){
            throw new IllegalArgumentException("El nombre del festival no puede ser null");}
    
    this.nombre = nombre;
    actividades = new ArrayList<>();}
    
    public String getNombre(){
        return nombre;}
    
    public void agregarActividad(Actividad actividad) throws ActividadDuplicadaException{
        if (actividad == null){
            throw new IllegalArgumentException("La actividad no puede ser null");}
        if (actividades.contains(actividad)){
            throw new IllegalArgumentException("La actividad con codigo:" + actividad.getCodigo() + "y titulo " + actividad.getTitulo());}
        actividades.add(actividad);
    }
    public List<Actividad> obtenerActividades(){
        return new ArrayList<>(actividades);}
    
    public List<Actividad> filtrarPorFranja(FranjaHoraria franja){
        if (franja == null){
            throw new IllegalArgumentException("La franja horaria no puede ser null");}
        List<Actividad> resultado = new ArrayList<>();
        for (Actividad a : actividades){
            if (a.getFranja() == franja){
                resultado.add(a);}
        }
        return resultado;        
    }
    public List<Actividad> obtenerActividadesDeDuracionMaxima(int limite){
        if (limite <= 0){
            throw new IllegalArgumentException("El limite debe ser positivo");
        }
        List<Actividad> resultado = new ArrayList<>();
        for (Actividad a : actividades){
            if (a.calcularDuracionTotal() <= limite){
                resultado.add(a);}
        }
        return resultado;
    }
}
