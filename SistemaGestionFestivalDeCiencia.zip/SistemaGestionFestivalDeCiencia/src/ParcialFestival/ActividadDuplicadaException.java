/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ParcialFestival;

/**
 *
 * @author tob
 */
public class ActividadDuplicadaException extends Exception{
    public ActividadDuplicadaException(String codigo, String titulo){
        super ("Ya existe la actividad " + codigo + " - " + titulo + ".");}
}
