/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ParcialFestival;
import java.util.Objects;
/**
 *
 * @author tob
 */
public abstract class Actividad {
    private String codigo;
    private String titulo;
    private FranjaHoraria franja;
    private int duracionBase;
    
    public Actividad(String codigo, String titulo, FranjaHoraria franja, int duracionBase){
        validarTexto(codigo, "codigo");
        validarTexto(titulo, "titulo");
        if (franja == null){
            throw new IllegalArgumentException("La franja horaria es obligatoria");}
    
        validarPositivo(duracionBase, "duracion base");
        this.codigo = codigo;
        this.titulo = titulo;
        this.franja = franja;
        this.duracionBase = duracionBase;
    }


public String getCodigo(){
    return codigo;}

public String getTitulo(){
    return titulo;}

public FranjaHoraria getFranja(){
    return franja;}

public abstract int calcularDuracionTotal();

protected static void validarTexto(String palabra, String campo){
    if (palabra == null || palabra.trim().equals("")){
        throw new IllegalArgumentException("El campo" + campo + "no puede ser null ni estar en blanco");
    }
}

protected static void validarPositivo(int num, String campo){
    if (num <= 0){
        throw new IllegalArgumentException("El valor de" + campo + "debe ser mayor que cero");}
}

@Override
public boolean equals (Object obj){
    if (obj instanceof Actividad){
        Actividad otra = (Actividad) obj;
        return codigo.equals(otra.codigo) && titulo.equals(otra.titulo);
    }
    return false;
}

public int hasCode(){
    return Objects.hash(codigo, titulo);}

@Override
public String toString(){
    return "codigo=" + codigo + ", titulo=" + titulo + ", franja=" + franja + ", duracionBase=" + duracionBase;
}
}
