/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ParcialFestival;

/**
 *
 * @author tob
 */
public class Charla extends ActividadReservable implements Presentable {
    private int minutosPreguntas;
    
    public Charla(String codigo, String titulo, FranjaHoraria franja, int duracionBase, int minutosPreguntas, int cupos){
        super(codigo, titulo, franja, duracionBase, cupos);
        validarNoNegativo(minutosPreguntas, "minutos de preguntas");
        this.minutosPreguntas = minutosPreguntas;
    }
    
    public int getMinutosPreguntas(){
        return minutosPreguntas;}
    
    @Override
    public int calcuarDuracionTotal(){
        return getDuracionBase() + minutosPreguntas;}
    
    @Override
    public String presentar(){
        return "Presentacion de charla: " + getTitulo() + ".";
    }
    
    @Override
    public String toString(){
        return "Charla [" + super.toString() + ", minutosPreguntas=" + minutosPreguntas + ", cupos=" + getCupos() + "]";}
}
