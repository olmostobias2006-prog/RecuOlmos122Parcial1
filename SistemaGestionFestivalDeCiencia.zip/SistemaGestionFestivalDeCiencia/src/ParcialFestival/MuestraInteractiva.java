/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ParcialFestival;

/**
 *
 * @author tob
 */
public class MuestraInteractiva extends Actividad implements Presentable{
    private int estaciones;
    private int minutosPorEstacion = 5;
    
    public MuestraInteractiva(String codigo, String titulo, FranjaHoraria franja, int duracionBase, int estaciones){
        super(codigo, titulo, franja, duracionBase);
        validarPositivo(estaciones, "estaciones");
        this.estaciones = estaciones;}
    
    public int getEstaciones(){
        return estaciones;}
    
    @Override
    public int calcularDuracionTotal(){
        return getDuracionBase() + minutosPorEstacion * estaciones;}
    
    @Override
    public String toString(){
        return "muestraInteractiva [" + super.toString() + ", estaciones=" + getEstaciones() + "]";}
}
